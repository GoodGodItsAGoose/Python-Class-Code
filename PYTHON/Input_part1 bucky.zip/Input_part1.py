
myname = input("Please type your name:")
print(f"\nHello, {myname}!")

myquestion =int(input("Please enter the first number of your equation:"))
print(type(myquestion))

mysymbol = input("Please enter either plus, minus, times, or divided:")
print(type(mysymbol))

myquestion2 =int(input("Please enter the second number of your equation:"))
print(type(myquestion2))

addition = {myquestion};{mysymbol};{myquestion2}
print(addition)

if mysymbol == "plus" or mysymbol == "Plus":
    print(myquestion + myquestion2)
elif mysymbol == "minus" or mysymbol == "Minus":
    print(myquestion - myquestion2)
elif mysymbol == "times" or mysymbol == "Times":
    print(myquestion * myquestion2)
elif mysymbol == "divided" or mysymbol == "Divided":
    print(myquestion / myquestion2)
else: 
    print("Follow directions, please. You're not in kindergarten anymore.")
